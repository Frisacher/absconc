#' @title Spectrophotometry concentration calculator
#' @description
#' \code{absconc} calculates the concentration of a chemical species using the absorbance and the standard curve parameters.
#' 
#' This is a simple function that uses a linear equation y=a*x+b to calculate chamical concentration from spectrophotometry assay.
#' @param x Absorbance of the assay (Numeric, string).
#' @param a Slope of the calibration curve (numeric)
#' @param b Intercept of the calibration curve (numeric).
#' 
#' @examples  
#' x<-c(0.252,0.524,0.625,0.128)
#' c <- absconc(x,1.5,5)
#' @seealso 
#' \url{https://github.com/Frisacher/absconc}

#' @export
absconc<-function(x,a,b,...)
{
  a<-as.numeric(a)
  b<-as.numeric(b)
  
  absconcCalc<- function(x,a,b,...)
  {
    conc<- (x*a)+b
  }
  conc<-absconcCalc(x,a,b,...)
  
  print.absconc<- function(x,a,b,...)
  {
    cat("Slope:")
    cat(a,"\n")
    cat("Intercept:")
    cat(b,"\n")
    cat("Concentration:")
    cat(conc)
  }
  print.absconc(x,a,b)
}